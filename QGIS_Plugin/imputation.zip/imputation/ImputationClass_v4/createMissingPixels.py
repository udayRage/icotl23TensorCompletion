import pandas as pd
import numpy as np
from imputation import Imputation
from geotiff import GeoTiff as gt
from osgeo import gdal
# from imputer import ImputationAlgo
from imputerNew import Imputation as ImpNew

class ImputationTest:
    def __init__(self,img, brightness):
        # if type(image) == pd.DataFrame:
        #     self.dataframe = dataframe
        #     self.img, self.pts_arr = df2np(dataframe)
        # elif type(img) == str :       
        self.img = np.array(gt(img).read())
        self.imp = Imputation(self.img)
        self.imp.set_brightness(brightness)
        # self.imp.show_img(self.imp.img)
        self.visArray = []
        self.mask = None

    def tifConversion(self,result,outputFileName):
        # print('numpy 2 tif conversion',result.shape)
        driver = gdal.GetDriverByName('GTiff')
        output_file = driver.Create(outputFileName,result.shape[0], result.shape[1],
                            result.shape[2],
                                    gdal.GDT_Float32)
        for band_range in range(result.shape[2]):
            output_file.GetRasterBand(band_range + 1).WriteArray(result[:, :, band_range])
        # output_file.SetGeoTransform(self.dataset.GetGeoTransform())
        # output_file.SetProjection(self.dataset.GetProjection())

    def createHIL(self,outputFileName):
        self.mask,self.corruptImg = self.imp.draw_mask()
        print(self.mask.size, self.corruptImg.shape[1])
        # self.imp.show_img(self.corruptImg)
        self.tifConversion(self.corruptImg, outputFileName)

    def predictHIL(self,img):
        imp = ImpNew(self.corruptImg,12)
        #
        if self.mask.all() == None:
            print("No previous mask")
            self.currentMask = imp.generate_mask(60)
            result = imp.impute(algo='CP_ALS', mask=self.currentMask, speed="slow",
                                tol=1e-4)
            self.imp.show_img(result)
        else:
            print("Using previous mask")
            result = imp.impute(algo='CP_ALS', mask = self.mask, speed="slow",
                            tol=1e-4)
            self.imp.show_img(result)
        print("---------")

        impArray = self.imp.impute(speed="fast", hil=0)

        self.imp.show_img(impArray)

        # test = self.imp.get_best_np()

        self.imp.visualize()

impTest = ImputationTest('/home/raashika/Desktop/output/fine1.tsv',0.0006)
impTest.createHIL('images/missingPixels1.tif')
impTest.predictHIL('images/missingPixels1.tif')